/** Automatically generated file. DO NOT MODIFY */
package cpsc112.game;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}