# howto_co34pt_livecode - Sample list/attribution

TODO: Multiple sample sets, switchable from within SuperCollider

Sample set 1 - Heavy electronic percussion from Corrosionred
- k = basic kick, all quite powerful though.
- s = basic snare
- c = basic clap
- t = basic tom
- ch = closed hat
- oh = open hat
- sk = sub kick
- pk = pitched kick
- ht = 'hi tom', in this case hi brakedrum-type sound
- mt = 'mid tom', ...
- ding = 'diiiiiiiiing'
- fx = longer effects sounds, to be used sparingly
- sfx = shorter effects sounds, usually percussive in nature
- q = quieter sounds
- lfx = longer-er effects sounds, to be used super sparingly
- gab = distorted long gabber kicks
